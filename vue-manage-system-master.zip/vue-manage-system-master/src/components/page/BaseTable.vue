<template>
    <div class="table">
        <div class="crumbs">
            <el-breadcrumb separator="/">
                <el-breadcrumb-item><i class="el-icon-lx-cascades"></i> 订单列表</el-breadcrumb-item>
            </el-breadcrumb>
        </div>
        <div class="container">
            <div class="handle-box">
                <el-button type="danger" icon="el-icon-circle-plus-outline" class="handle-del mr10" @click="handleAdd()">新增订单</el-button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <el-input v-model="select_word" placeholder="筛选关键词" class="handle-input mr10"></el-input>
                <el-button type="primary" icon="el-icon-search" @click="search">搜索</el-button> 
            </div>
            <el-table :data="data" border class="table" ref="multipleTable" @selection-change="handleSelectionChange">
                <el-table-column prop="order_date" label="日期" sortable width="150">
                </el-table-column>
                <el-table-column prop="order_name" label="姓名" width="200">
                </el-table-column>
                <el-table-column prop="order_address" label="地址" width="450">
                </el-table-column>
                <el-table-column prop="order_id" label="订单号" width="180">
                </el-table-column>
                <el-table-column prop="order_track" label="快递单号" width="180">
                </el-table-column>
                <el-table-column prop="order_number" label="数量" width="50">
                </el-table-column>
                <el-table-column prop="order_product" label="货物名称" width="100">
                </el-table-column>
                <el-table-column prop="order_remark" label="备注信息">
                </el-table-column>
                <el-table-column label="操作" width="180" align="center">
                    <template slot-scope="scope">
                        <el-button type="text" icon="el-icon-edit" @click="handleEdit(scope.row)">编辑</el-button>
                        <el-button type="text" icon="el-icon-delete" class="red" @click="handleDel(scope.row)">删除</el-button>
                    </template>
                </el-table-column>
            </el-table>
            <div class="pagination">
                <el-pagination background @current-change="handleCurrentChange" layout="prev, pager, next" :total="totalCount">
                </el-pagination>
            </div>
        </div>
            
        <!-- 新增弹出框 -->
        <el-dialog title="新增订单" :visible.sync="addVisible" width="30%">
            <el-form ref="form" :model="form" label-width="100px">
                <el-form-item label="日期 : ">
                    <el-date-picker type="date" placeholder="选择日期" v-model="form.date" value-format="yyyy-MM-dd" style="width: 100%;"></el-date-picker>
                </el-form-item>
                <el-form-item label="姓名 ">
                    <el-input v-model="form.name" style="width: 100%;"></el-input>
                </el-form-item>
                <el-form-item label="地址 ">
                    <el-input v-model="form.address" style="width: 100%;"></el-input>
                </el-form-item>
                <el-form-item label="订单号 ">
                    <el-input v-model="form.id" style="width: 69%;" placeholder="手动添加淘宝订单号,点击生成非淘宝订单号"></el-input>
                    <el-button type="danger" @click="createId">生成非淘宝订单号</el-button>
                </el-form-item>
                <el-form-item label="快递单号 ">
                    <el-input v-model="form.track" style="width: 100%;"></el-input>
                </el-form-item>
                <el-form-item label="货物 ">
                    <el-input v-model="form.product" style="width: 100%;"></el-input>
                </el-form-item>
                <el-form-item label="数量 ">
                    <el-input-number v-model="form.number" @change="handleNumberChange" :min="1" :max="1000" ></el-input-number>
                </el-form-item>
                <el-form-item label="备注信息 ">
                    <el-input v-model="form.remark" style="width: 100%;"></el-input>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="addVisible = false">取 消</el-button>
                <el-button type="primary" @click="saveAdd">确 定</el-button>
            </span>
        </el-dialog>

        <!-- 编辑弹出框 -->
        <el-dialog title="编辑订单" :visible.sync="editVisible" width="30%">
            <el-form ref="form" :model="form" label-width="100px">
                <el-form-item label="日期 : ">
                    <el-date-picker type="date" placeholder="选择日期" v-model="form.date" value-format="yyyy-MM-dd" style="width: 100%;"></el-date-picker>
                </el-form-item>
                <el-form-item label="姓名 ">
                    <el-input v-model="form.name" style="width: 100%;">></el-input>
                </el-form-item>
                <el-form-item label="地址 ">
                    <el-input v-model="form.address" style="width: 100%;">></el-input>
                </el-form-item>
                <el-form-item label="订单号 ">
                    <el-input v-model="form.id" disabled style="width: 100%;">></el-input>
                </el-form-item>
                <el-form-item label="快递单号 ">
                    <el-input v-model="form.track" style="width: 100%;">></el-input>
                </el-form-item>
                <el-form-item label="货物 ">
                    <el-input v-model="form.product" style="width: 100%;">></el-input>
                </el-form-item>
                <el-form-item label="数量 ">
                    <el-input-number v-model="form.number" @change="handleNumberChange" :min="1" :max="1000" ></el-input-number>
                </el-form-item>
                <el-form-item label="备注信息 ">
                    <el-input v-model="form.remark" style="width: 100%;">></el-input>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="editVisible = false">取 消</el-button>
                <el-button type="primary" @click="saveEdit">确 定</el-button>
            </span>
        </el-dialog>

        <!-- 删除弹出框 -->
        <el-dialog title="删除订单" :visible.sync="delVisible" width="30%">
            <p>确定删除该订单吗?</p>
            <span slot="footer" class="dialog-footer">
                <el-button @click="delVisible = false">取 消</el-button>
                <el-button type="primary" @click="saveDel">确 定</el-button>
            </span>
        </el-dialog>

    </div>
</template>

<script>
    export default {
        name: 'basetable',
        data() {
            return {
                tableData:[],
                currentData:[],
                cur_page: 1,
                multipleSelection: [],
                select_cate: '',
                select_word: '',
                del_list: [],
                is_search: false,
                totalCount: 0,
                addVisible: false,
                editVisible: false,
                delVisible: false,
                form: {
                    name: '',
                    date: '',
                    address: '',
                    id: '',
                    track: '',
                    product: '',
                    number: '',
                    remark:''
                },
                delId:'',
                idx: -1
            }
        },
        created() {
            this.getData();
        },
        computed: {
            data() {
                return this.tableData.filter((d,index) => {

                    if(this.select_word){
                        if (d.order_address.indexOf(this.select_word) > -1 || d.order_name.indexOf(this.select_word) > -1) {
                            return d;
                        }
                    }else{
                        if(index >= (this.cur_page - 1) * 10 && index < (this.cur_page) * 10 ){
                            return d
                        }
                    }
                    
                })
            }
        },
        methods: {
            // 分页导航
            handleCurrentChange(val) {
                this.cur_page = val;
                this.getData();
            },
            getData() {
                this.$axios.get('http://192.168.0.107:3100/allOrder').then((res) => {
                    this.tableData = res.data.list;
                    this.totalCount = res.data.list.length;
                    // console.log(this.cur_page,'---------')
                    // let newData = [];
                    // let start = (this.cur_page - 1) * 10;
                    // let end = (this.cur_page ) * 10;
                    // for(let i=start;i<end;i++){
                    //     newData.push(res.data.list[i])
                    // }
                    // this.tableData = newData
                })
            },
            search() {
                this.is_search = true;
            },
            formatter(row, column) {
                return row.address;
            },
            filterTag(value, row) {
                return row.tag === value;
            },
            handleAdd() {
                this.addVisible = true;
                this.form = {
                    name: '',
                    date: '',
                    address: '',
                    id: '',
                    track: '',
                    product: '',
                    number: '',
                    remark: ''
                }
            },
            handleEdit(row) {
                this.editVisible = true;
                this.form = {
                    name: row.order_name,
                    date: row.order_date,
                    address: row.order_address,
                    id: row.order_id,
                    track: row.order_track,
                    product: row.order_product,
                    number: row.order_number,
                    remark: row.order_remark
                }    
            },
            handleDel(row) {
                this.delVisible = true;
                this.delId = row.order_id;
            },
            handleSelectionChange(val) {
                this.multipleSelection = val;
            },
            handleNumberChange() {

            },
            // 保存新增
            saveAdd() {
                // 发送请求保存新增数据
                this.$axios.post('http://192.168.0.107:3100/orderAdd',{
                    order:{
                        "order_id":this.form.id,
                        "order_date":this.form.date,
                        "order_name":this.form.name,
                        "order_address":this.form.address,
                        "order_track":this.form.track,
                        "order_number":this.form.number,
                        "order_product":this.form.product,
                        "order_remark":this.form.remark
                    }
                }).then((res) => {
                    // this.tableData = res.data.list
                    if(res.data.code === 1){
                        this.addVisible = false;
                        this.$message({
                           type: 'success',
                           message:'订单添加成功',
                           duration: 1000 
                        });
                        this.getData()
                    }else{
                        this.addVisible = false;
                        this.$message({
                            type: 'error',
                            message: '订单添加失败,订单号不能重复！',
                            duration: 2000
                        })
                    }
                })     
            }, 
            
            // 保存编辑
            saveEdit() {
                // 发送请求保存修改数据
                this.$axios.post('http://192.168.0.107:3100/orderEdit',{
                    order:{
                        "order_id":this.form.id,
                        "order_date":this.form.date,
                        "order_name":this.form.name,
                        "order_address":this.form.address,
                        "order_track":this.form.track,
                        "order_number":this.form.number,
                        "order_product":this.form.product,
                        "order_remark":this.form.remark
                    }
                }).then((res) => {
                    // this.tableData = res.data.list
                    if(res.data.code === 1){
                        this.editVisible = false;
                        this.$message({
                           type: 'success',
                           message:'订单修改成功',
                           duration: 1000 
                        });
                        this.getData()
                    }else{
                        this.editVisible = false;
                        this.$message({
                            type: 'error',
                            message: '订单修改失败',
                            duration: 1000
                        });
                       
                    }
                })
            },

            // 保存删除
            saveDel() {
                // console.log(this.delId)
                // 发送请求
                this.$axios.post('http://192.168.0.107:3100/orderDel',{
                    order:{
                        "order_id":this.delId
                    }
                }).then((res) => {
                    // console.log(res.data)
                    if(res.data.code === 1){
                        this.delVisible = false;
                        this.$message({
                           type: 'success',
                           message:'订单删除成功',
                           duration: 1000 
                        });
                        this.getData()
                    }else{
                        this.delVisible = false;
                        this.$message({
                            type: 'error',
                            message: '订单删除失败',
                            duration: 1000
                        });
                    }
                })
            },

            // 生成非淘宝订单号
            createId() {
                let id = 'xstrive';

                // 生成11位随机数
                let rand = "";
                for(let i=0;i<11;i++){
                    let r = Math.floor(Math.random() * 10);
                    rand += r;
                }
                id += rand;
                this.form.id = id
            }
        }
    }

</script>

<style scoped>
    .handle-box {
        margin-bottom: 20px;
    }

    .handle-select {
        width: 120px;
    }

    .handle-input {
        width: 300px;
        display: inline-block;
    }
    .del-dialog-cnt{
        font-size: 16px;
        text-align: center
    }
    .table{
        width: 100%;
        font-size: 14px;
    }
    .red{
        color: #ff0000;
    }
    .crumbs {
        margin: 10px 0;
    }
    .el-input {
        width: auto;
    }
</style>
